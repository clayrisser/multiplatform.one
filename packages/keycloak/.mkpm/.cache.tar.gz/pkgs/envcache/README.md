# envcache

> cache calculated envs for faster load time
