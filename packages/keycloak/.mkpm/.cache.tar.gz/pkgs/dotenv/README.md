# mkpm-dotenv

> dotenv support for makefiles
